package boundary;

import javax.swing.JFrame;

public class BugBoardFrame extends JFrame
{
	public BugBoardFrame()
	{
		this.setSize(800, 600);
		this.setVisible(true);
	}
}
