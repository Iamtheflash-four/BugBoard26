package boundary;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.MatteBorder;

import Controller.LoginController;

public class LoginArea extends JFrame 
{
	private LoginController controller;
	private JPanel mainPanel;
	private JLabel title;
	private JPanel titlePanel;
	
	private JLabel emailLabel;
	private JTextField emailField;
	
	private JLabel passwordLabel;
	private JTextField passwordField;
	
	public LoginArea(LoginController controller)
	{
		this.controller = controller;
		this.setSize(400, 600);
		
		//Title
		title = createLabel("BugBoard26", Color.BLUE, 20);
		//title.setAlignmentX(Component.CENTER_ALIGNMENT);
		
		titlePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		titlePanel.setSize(300, 40);
		titlePanel.setMaximumSize(new Dimension(300, 40));
		
		//Username field 
		emailLabel = createFieldLabel("Indirizzo email");
		emailField = createLoginField("nome@email.com");
		
		//Password field 
		passwordLabel = createFieldLabel("Password");
		passwordField = createLoginField("xxxxx");
		
		//ContentPanel
		mainPanel = new JPanel();
		mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
		mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
		mainPanel.setSize(300, 500);
		
		titlePanel.add(title);
		mainPanel.add(titlePanel);
		mainPanel.add(Box.createVerticalStrut(15));
		mainPanel.add(emailLabel);
		mainPanel.add(emailField);
		mainPanel.add(passwordLabel);
		mainPanel.add(passwordField);
		mainPanel.setVisible(true);
		
		this.setContentPane(mainPanel);
		setVisible(true);
	}
	
	private JTextField createLoginField(String text) {
		JTextField  field = new JTextField();
		field.setText(text);
		field.setBorder(new MatteBorder(0, 0, 2, 0, Color.BLUE));
	    field.setAlignmentX(Component.LEFT_ALIGNMENT);
		// Size
	    Dimension dim = new Dimension(350, 30);
	    field.setPreferredSize(dim);
	    field.setMaximumSize(dim); 
	    field.setMinimumSize(dim);
		
		return field;
	}

	private JLabel createFieldLabel(String text)
	{
		JLabel label = new JLabel(text);
		label.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 12));
		label.setForeground(Color.BLUE);
		return label;
	}


	private JLabel createLabel(String text, Color color, int size)
	{
		JLabel label = new JLabel(text);
		label.setFont(new Font(Font.SANS_SERIF, Font.BOLD, size));
		label.setForeground(color);
		return label;
	}
}
